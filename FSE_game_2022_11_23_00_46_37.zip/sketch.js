let currentActivity = 0;
let menuButton, game1Button, game2Button, game3Button, restartButton, scoreButton, instructionButton;
let score;
let gameNumber;
let trail = [];
let song;

var circles = [];
var bg;

function preload() {
  game1Preload();
  game2Preload();
  game3Preload();
  instructionPreload();
  bg = loadImage("background.jpeg");
  song = loadSound('score.wav');
}

function switchToMM() {
  bg = loadImage("background.jpeg");
  background(bg);
  currentActivity = 0;
  
  // Hide the home page button, show the activity buttons
  menuButton.hide();
  game1Button.show();
  game2Button.show();
  game3Button.show();
  scoreButton.hide();
  instructionButton.show();
}

function setup() {
  createCanvas(600,600);
  background(220);
  menuButton = createButton('Home Page');
  menuButton.textSize = 50;
  menuButton.size(120,50);
  menuButton.position(10, 10);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();
  
  game1Button = createButton('Rectangle');
  game1Button.size(100,50);
  game1Button.position(70, 300);
  game1Button.mousePressed(game1Setup);
  game1Button.show();
  
  game2Button = createButton('Triangle');
  game2Button.size(100,50);
  game2Button.position(250, 300);
  game2Button.mousePressed(game2Setup);
  game2Button.show();
  
  game3Button = createButton('Circle');
  game3Button.size(100,50);
  game3Button.position(430, 300);
  game3Button.mousePressed(game3Setup);
  game3Button.show();
 
  scoreButton = createButton('See Score');
  scoreButton.size(150,50);
  scoreButton.position(440, 540);
  scoreButton.mousePressed(scoreSetup);
  scoreButton.hide();
  
  instructionButton = createButton('Instructions');
  instructionButton.size(150,50);
  instructionButton.position(440, 540);
  instructionButton.mousePressed(instructionSetup);
  instructionButton.show();
}


function draw() { 
  switch(currentActivity) {
    case 0: 
      mainMenu();
      break;
    case 1: 
      game1Draw();
      break;
    case 2: 
      game2Draw();
      break;
    case 3: 
      game3Draw();
      break;
    case 4:
      scoreDraw();
      break;
    case 5:
      instructionDraw();
      break;
  }
}

function mainMenu(){
  background(bg);
  
  fill("rgb(255,239,186)");
  textSize(50);
  textFont('sans-serif');
  stroke('black');
  text('SHAPE PLAYGROUND',30, 200);
}

function overRect(x, y, length, width) {
  if (mouseX >= x && mouseX <= x+length && mouseY >= y && mouseY <= y+width) {
    return true;
  } else {
    return false;
  }
}

function drawTrail() {
  stroke(255);
  fill(59-mouseX/5, 234-mouseY/5, 78-mouseX/5);
  for (let i = 0; i < trail.length; i++) {
    let p = trail[i];

    // The trail is smaller at the beginning,
    // and larger closer to the mouse
    let size = 30.0 * i / trail.length;
    if (size < 10) {
      size = 10;
    }
    circle(p.x, p.y, size);
  }
  if (mouseIsPressed && overRect(55,165,490,320)) {
    trail.push(new p5.Vector(mouseX, mouseY));
    drawingGameUpdate();
  }
}

function drawingGameUpdate() {
   for (let c of circles) {
     if (c.overCircle() && c.marked==false){
       score += 100/circles.length;
       c.marked = true;
     }
   }
}

function mousePressed() {
  if (overRect(55,165,490,320)) {
    trail = [];
    if (currentActivity > 0 && currentActivity <= 3) {
      score = 0;
      for (let c of circles) {
        c.marked = false;
      }
    }
  }
}