let instructionPic;

function instructionPreload() {
  instructionPic = loadImage("Instruction/img.png");
}

function instructionSetup() {
  currentActivity = 5;

  menuButton.show();
  game1Button.hide();  
  game2Button.hide();
  game3Button.hide();
  instructionButton.hide();
  
  bg = loadImage("background.jpeg");
  instructionPic.resize(500, 350);
}

function instructionDraw() {
  background(bg);
  
  textSize(40);
  text('How to Play', 190, 100);
  textSize(30);
  text('Draw along the border.',150, 180);
  image(instructionPic, 50, 210);
}