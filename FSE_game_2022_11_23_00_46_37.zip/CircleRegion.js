class CircleRegion{
  constructor(x, y, radius, marked){
    circle(x,y,radius);
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.marked = marked;
  }
  
  overCircle(){
    if(sqrt((mouseX-this.x)**2+(mouseY-this.y)**2)<=this.radius){
      return true;
    } else {
      return false;
    }
  }
}