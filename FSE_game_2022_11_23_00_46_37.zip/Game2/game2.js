let image2;

function game2Preload(){
  image2 = loadImage("Game2/triangle.png");
}

function game2Setup(){
  currentActivity = 2;
  gameNumber = currentActivity;
  score = 0;
  
  circles=[];
  circles[0] = new CircleRegion(185,425,20,false);
  circles[1] = new CircleRegion(300,225,20,false);
  circles[2] = new CircleRegion(415,425,20,false);
  
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  scoreButton.show();
  instructionButton.hide();
  
  bg = loadImage("image.jpeg");
  image2.resize(250, 250);
}

function game2Draw(){
  //triangle(185,425,300,225,415,425);
  
  background(bg);
  
  fill("rgba(213,214,226,0.79)");
  stroke("black");
  rect(40,150,520,350);
  
  noStroke();
  fill('black');
  textSize(50);
  text('Triangle', 205, 100);
  image(image2, 175, 200);

  drawTrail();
}