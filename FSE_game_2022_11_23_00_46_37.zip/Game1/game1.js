let image1;

function game1Preload(){
  image1 = loadImage("Game1/rectangle.png");
}

function game1Setup(){
  currentActivity = 1;
  gameNumber = currentActivity;
  score = 0;
  
  circles=[];
  circles[0] = new CircleRegion(195,265,20,false);
  circles[1] = new CircleRegion(195,385,20,false);
  circles[2] = new CircleRegion(395,265,20,false);
  circles[3] = new CircleRegion(395,385,20,false);
  
  menuButton.show();
  game1Button.hide();  
  game2Button.hide();
  game3Button.hide();
  scoreButton.show();
  instructionButton.hide();
  
  bg = loadImage("image.jpeg");
  image1.resize(250, 250);
}

function game1Draw(){
  //rect(185, 265, 200, 120);
  
  background(bg);
  
  fill("rgba(213,214,226,0.79)");
  stroke("black");
  rect(40,150,520,350);
  
  noStroke();
  fill('black');
  textSize(50);
  text('Rectangle', 190, 100);
  image(image1, 170, 200);
  
  drawTrail();
}