let image3;

function game3Preload(){
  image3 = loadImage("Game3/circle.png");
}

function game3Setup(){
  currentActivity = 3;
  gameNumber = currentActivity;
  score = 0;
  
  circles=[];
  circles[0] = new CircleRegion(410,325,20,false);
  circles[1] = new CircleRegion(160,325,20,false);
  circles[2] = new CircleRegion(285,450,20,false);
  circles[3] = new CircleRegion(285,200,20,false);
  
  menuButton.show();
  game1Button.hide();
  game2Button.hide();
  game3Button.hide();
  scoreButton.show();
  instructionButton.hide();

  bg = loadImage("image.jpeg");
  image3.resize(250, 250);
}

function game3Draw(){
  // circle(285,325,250);
  
  background(bg);
  
  fill("rgba(213,214,226,0.79)");
  stroke("black");
  rect(40,150,520,350);
  
  noStroke();
  fill('black');
  textSize(50);
  text('Circle', 220, 100);
  image(image3, 160, 200);
  
  drawTrail();
}