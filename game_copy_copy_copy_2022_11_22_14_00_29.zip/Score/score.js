function scoreSetup(){
  currentActivity = 4;
  score = Math.floor(score);
  trail = [];
  scoreButton.hide();
  song.play();
  bg = loadImage("background.jpeg");
}

function scoreDraw(){
  background(bg);
  fill("rgba(164,172,229,0.79)");
  stroke("black");
  rect(60,90,480,400);
  
  scoreReport();
}

function scoreReport(){
  noStroke();
  fill("rgb(255,239,186)");
  textSize(40);
  text('SCORE DISPLAY', 125, 170);
  textSize(26);
  text('For level ' + gameNumber + ",", 125, 300);
  text('you got a score of '+ score + '.', 125, 400);
}

